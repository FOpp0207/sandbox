// Function to validate form data using regular expressions
function validateFormData() {
// Regular expressions for phone number, email, and Canadian postal
code validation
const phoneRegex = /^[0-9]{3} [0-9]{3} [0-9]{4}$/;
const emailRegex = /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/;
const postalCodeRegex = /^[A-Za-z][0-9][A-Za-z] [0-9][A-Za-z][0-9]$/;
// Fetch form data
const fullName = document.getElementById('fullname').value;
const address = document.getElementById('address').value;
const postalCodeInput = document.getElementById('postalcode');
const postalCode = postalCodeInput.value;
const phoneNumberInput = document.getElementById('phone');
const phoneNumber = phoneNumberInput.value;
const emailInput = document.getElementById('email');
const email = emailInput.value;
const pickupDate = document.getElementById('pickup_date').value;
// Validate phone number, email, and postal code using regular expressions
if (!phoneRegex.test(phoneNumber)) {
phoneNumberInput.setCustomValidity('Please enter a valid phone number
in the format "XXX XXX XXXX".');
phoneNumberInput.reportValidity();
return;
} else {
phoneNumberInput.setCustomValidity('');
}
if (!emailRegex.test(email)) {
emailInput.setCustomValidity('Please enter a valid email address.');
emailInput.reportValidity();
return;
} else {
emailInput.setCustomValidity('');
}
if (!postalCodeRegex.test(postalCode)) {
postalCodeInput.setCustomValidity('Please enter a valid Canadian
postal code in the format "ANA NAN".');
postalCodeInput.reportValidity();
return;
} else {
postalCodeInput.setCustomValidity('');
}
// Display form data in an alert box
const output =
`Name: ${fullName}
Address: ${address}
Postal code: ${postalCode}
Telephone: ${phoneNumber}
e-mail: ${email}
Order Pickup Date: ${pickupDate}`;
alert(output);
}
// Add event listener to the form submit button
const submitButton = document.getElementById('submit_button');
submitButton.addEventListener('click', validateFormData);
// Add event listener to the form reset button
const resetButton = document.getElementById('reset_button');
resetButton.addEventListener('click', function () {
document.getElementById('myform').reset();
});